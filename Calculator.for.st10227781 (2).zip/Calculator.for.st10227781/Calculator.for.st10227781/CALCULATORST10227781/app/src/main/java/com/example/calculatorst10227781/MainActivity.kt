package com.example.calculatorst10227781

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal


class MainActivity : AppCompatActivity() {

    private var valFigure1 : TextView? = null
    private var valFigure2 : TextView? = null
    private var valResponse : TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        valFigure1 = findViewById(R.id.figure1)
        valFigure2 = findViewById(R.id.figure2)
        valResponse = findViewById(R.id.result)

        val btnAdd = findViewById<Button>(R.id.addBtn)
        val btnSub = findViewById<Button>(R.id.subBtn)
        val btnMul = findViewById<Button>(R.id.mulBtn)
        val btnDiv = findViewById<Button>(R.id.divBtn)


        btnAdd.setOnClickListener()
        {
            add()
        }
        btnSub.setOnClickListener()
        {
            subtract()
        }
        btnMul.setOnClickListener()
        {
            multiply()
        }
        btnDiv.setOnClickListener()
        {
            divide()
        }

    }

    private fun divide() {
        if (inputIsNotEmpty()) {
            val input1 = valFigure1?.text.toString().trim().toBigDecimal()
            val input2 = valFigure2?.text.toString().trim().toBigDecimal()

            if (input2.compareTo(BigDecimal.ZERO) == 0) {
                valResponse?.text = "Cannot divide by zero";
            } else {
                val result = input1 / input2
                valResponse?.text = "${result}"
            }
        }


    }


    private fun add()
    {

        if (inputIsNotEmpty())
        {
            val input1 = valFigure1?.text.toString().trim().toBigDecimal()
            val input2 = valFigure2?.text.toString().trim().toBigDecimal()
            valResponse?.text = input1.add(input2).toString()
        }

    }


    private fun subtract()
    {
        if (inputIsNotEmpty())
        {
            val input1 = valFigure1?.text.toString().trim().toBigDecimal()
            val input2 = valFigure2?.text.toString().trim().toBigDecimal()
            valResponse?.text = input1.subtract(input2).toString()
        }

    }


    private fun multiply() {
        if (inputIsNotEmpty()) {
            val input1 = valFigure1?.text.toString().trim().toBigDecimal()
            val input2 = valFigure2?.text.toString().trim().toBigDecimal()
            valResponse?.text = input1.multiply(input2).toString()
        }

    }

    private fun inputIsNotEmpty(): Boolean
    {
        var b = true
        if (valFigure1?.text.toString().trim().isEmpty())
        {
            valFigure1?.error = "Required"
            b = false
        }
        if (valFigure2?.text.toString().trim().isEmpty())
        {
            valFigure2?.error = "Required"
            b = false
        }
        return b
    }

}
